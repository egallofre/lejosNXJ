﻿Release notes for LEGO(R) MINDSTORMS(R) NXT Mobile Application


Overview
This software enables a number of specific mobile phones to control the NXT by Bluetooth. The list of phones currently supporting the NXT Mobile Application is available at www.mindstorms.com/bluetooth/

Disclaimer
This software is provided as-is without any warranty of any kind. The entire risk arising out the use or performance of the software remains with you. To the maximum extent permitted by applicable law, in no event shall the LEGO Group of Companies (including, but not limited to LEGO Systems A/S) and its suppliers and licensors, be liable for any damages arising out of the use or inability to use the software.

To install and use the software, you must agree to the terms of the License Agreement included with the software. Please be sure to read the License Agreement (EULA) before installing LEGO MINDSTORMS NXT Mobile Application on your phone.


Table of Contents:
 
1) System requirements 

	- NXT
	
	- Phone

2) Installing the NXT Mobile Application

3) Uninstalling the NXT Mobile Application

4) Usage

5) Help and support 

6) Legal 



1) SYSTEM REQUIREMENTS

MINDSTORMS NXT
The NXT Mobile Application is supported by NXT bricks with the following versions or later:
FW 1.03
AVR 1.01 
BC4 1.01

(You can find your version numbers on the NXT brick under 'Settings'…'NXT Version')

Mobile phone
Your phone must be Bluetooth enabled and capable of running Java (JSR-82). Phones listed in the NXT Mobile Application Compability Matrix currently supports the NXT Mobile Application:
www.mindstorms.com/bluetooth/

Make sure that your operator allows third party applications and that your phone's settings allow installation of java. You may have to change your phones settings to permit the use of Java applications (consult your phone’s instructions manual). 

Following the instructions in this document requires a Bluetooth enabled computer to install the NXT Mobile Application on your phone.

2) INSTALLING THE NXT MOBILE APPLICATION
1. First check that your phone supports the NXT Mobile Applications. You can find an overview on the MINDSTORMS website: www.mindstorms.com/bluetooth/ 
A more detailed Compatibility Matrix is included when you download the software.

2. Download the NXT Mobile Application software package and unpack the files on your computer.

3. Make sure Bluetooth is turned on your phone and the NXT

4. Locate the NXTmobile.jar file specific for your phone (make and model is indicated by folder names) and install it on your phone:

PC: Find the downloaded application and right click the file. Choose 'Send to' in the context menu and select 'Bluetooth unit'. Find and select your device and follow the instructions for your phone.

MAC: Click the Bluetooth icon in the top menu and choose 'Send file'. Find the NXTmobile.jar file in the zip-file you have downloaded and click 'Send'. Find your phone on the devices list and click 'Send'. Follow the instructions for your phone.


3) UNINSTALLING THE NXT MOBILE APPLICATION


Please refer to the instructions manual that came with your phone for detailed instructions on how to uninstall programs. Usually you just need to delete the program file from your phone.

4) USAGE
(Note: For instructions for more advanced usage download the NXT Mobile Application User Guide from www.mindsotmrs.com/bluetooth/)

When the NXT Mobile Application is started you have the following options from the Main Menu:

Info
A brief description of the NXT Mobile Application, where to find help and more information - and the terms for using the software.

Remote Control
This enables you to control two motors on the NXT. Use the joystick/command wheel on your phone to go forward, backwards, stop – or you can choose to control one motor at the time. If your NXT model have wheels (like the Tribot) it will be much like a remote controlled car.
See ‘Advanced Usage and Program Examples’ for more advanced remote control.

Program Control
This mode enables you to control any of the programs on your NXT. First select the program you want to control and then you can send command messages to your NXT by pressing the numeric keys on your phone. What the NXT does when you press the keys depends entirely on your program.
Tip: Download the two program examples included with the NXT Mobile Application for an easy introduction to program control (see the ‘Advanced Usage and Program Examples’)

Collected Data
If the NXT can make your phone take photos, this is where you can find them. Have you made a program that sends data to your phone, this is where you can find it as well, for instance be readings from the sensors.
Note: Collected data and images are deleted from the camera when you close the application.


5) HELP AND SUPPORT
We regret that due to the large variety of phones, configurations, and cell phone carriers, that we cannot currently offer direct technical support for this application. As new information becomes available it will become available at www.mindstorms.com/bluetooth/ 

6) LEGAL

The LEGO® MINDSTORMS® NXT Bluetooth Application is distributed by the LEGO Group, DK-7190 Billund, Denmark. 
Copyright © 2006 the LEGO Group and its licensors. 
LEGO, the LEGO logo and MINDSTORMS and the MINDSTORMS logo are trademarks of the LEGO Group.

Bluetooth is a trademark owned by Bluetooth SIG, Inc. and is licensed to the LEGO Group.

Sun, the Sun logo, Sun Microsystems, Java, and all Java-related trademarks are trademarks or registered trademarks of Sun Microsystems, Inc. in the U.S. and other countries, and are used here with permission. Copyright 1994-2006 Sun Microsystems, Inc.

The LEGO MINDSTORMS NXT Bluetooth Application is developed by NearCell, DK-8000 Aarhus, Denmark.



2006-10-16